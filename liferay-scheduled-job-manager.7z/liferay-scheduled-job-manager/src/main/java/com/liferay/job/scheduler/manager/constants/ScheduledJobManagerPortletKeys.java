package com.liferay.job.scheduler.manager.constants;

public class ScheduledJobManagerPortletKeys {

	public static final String LiferayScheduledJobManagerpanelapp = "LiferayScheduledJobManagerpanelapp";

}